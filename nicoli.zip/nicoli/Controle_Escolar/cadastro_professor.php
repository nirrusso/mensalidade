
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Cadastro Escolar</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
    <p class="text-center text-primary">CADASTRO<br> DO<br>
    <img src="imagens/logo_professor.png" alt="Logo Professor"></p>
    <form name="cadastro" method="post" action="">
        <table class="table table-bordered">
            <tr>
                <td class="text-primary"><label>Nome do professor:</label></td>
                <td><input type="text" name="nome_professor" size="60" maxlength="60" required></td>
            </tr>
            <tr>
                <td class="text-primary"><label>Cidade:</label></td>
                <td><input type="text" name="cidade" size="30" maxlength="30" required></td>
            </tr>
            <tr>
                <td class="text-primary">E-mail:</td>
                <td><input type="email" name="email" size="30" maxlength="30" required></td>
            </tr>
            <tr>
                <td class="text-primary">Contato:</td>
                <td><input type="text" name="contato" size="15" maxlength="15"></td>
            </tr>
            <tr>
                <td colspan="2" align="center" class="text-primary">
                    <input type="submit" value="Cadastrar" name="cadastrar" class="btn btn-primary">
                </td>
            </tr>
        </table>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        require "conexao.php";
        $nome_professor = $_POST["nome_professor"];
        $cidade = $_POST["cidade"];
        $email = $_POST["email"];
        $contato = $_POST["contato"];
        $sql="INSERT INTO tbprofessor (nome_professor, cidade, email, contato) VALUES ('$nome_professor', '$cidade', '$email', '$contato')";
        mysqli_query($conexao, $sql) or die(mysqli_error($conexao));


        //fecha a conexão com o banco de dados
        mysqli_close($conexao);
        echo "professor cadastro com sucesso!";

    }
    ?>
    </div>
</body>

</html>