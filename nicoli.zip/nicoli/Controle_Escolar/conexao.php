<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "bdescola";
$conexao = mysqli_connect($host, $user, $pass) or die("Erro ao conectar!");
mysqli_select_db($conexao, $banco) or die(mysqli_error($conexao));
mysqli_set_charset($conexao, "utf8");
?>