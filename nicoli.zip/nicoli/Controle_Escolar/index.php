<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Cadastro Escolar</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <header>
            <p class="text-center text-primary">CADASTRO ESCOLAR<br>
                Desenvolvido por Edson Pereira</p>
        </header>
        <nav class="text-center">
            <a href="cadastro_professor.php">Cadastro de Professor</a> |
            <a href="pesquisa_professor">Pesquisa de Professor</a> |
            <a href="contato.php">Contato</a>
        </nav>
        <footer>
            <main>
                <p class="text-center">
                    <img src="imagens/logo.png" alt="Logo">
                </p>
            </main>
            <p class="text-center text-dark"><strong><em>&copy; 2025 - Todos os direitos reservados</em></strong></p>
        </footer>
    </div>
</body>

</html>